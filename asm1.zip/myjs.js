document.getElementById("img1l").addEventListener("click",function(){
    document.getElementById("imageleft").src = "img/big1.jpg"
});

document.getElementById("img2l").addEventListener("click",function(){
    document.getElementById("imageleft").src = "img/big2.jpg"
});

document.getElementById("img3l").addEventListener("click",function(){
    document.getElementById("imageleft").src = "img/big3.jpg"
});

document.getElementById("img1r").addEventListener("click",function(){
    document.getElementById("imageright").src = "img/big4.jpg"
});

document.getElementById("img2r").addEventListener("click",function(){
    document.getElementById("imageright").src = "img/big5.jpg"
});

document.getElementById("img3r").addEventListener("click",function(){
    document.getElementById("imageright").src = "img/big6.jpg"
});

document.getElementById("img1t").addEventListener("click",function(){
    document.getElementById("imagetop").src = "img/big7.jpg"
});

document.getElementById("img2t").addEventListener("click",function(){
    document.getElementById("imagetop").src = "img/big8.jpg"
});

document.getElementById("img3t").addEventListener("click",function(){
    document.getElementById("imagetop").src = "img/big9.jpg"
});

document.getElementById("img1b").addEventListener("click",function(){
    document.getElementById("imagebottom").src = "img/big10.jpg"
});

document.getElementById("img2b").addEventListener("click",function(){
    document.getElementById("imagebottom").src = "img/big11.jpg"
});

document.getElementById("img3b").addEventListener("click",function(){
    document.getElementById("imagebottom").src = "img/big12.jpg"
});

/*********************I'm sleepy*****************/

var mypicl = document.getElementById("imageleft");
var myTop = 180;
var myRight = 70;
var myHeight = 150;
var myWidth = 200;

document.getElementById("rightl").addEventListener("click", function(){
    myRight = myRight+5;
    mypicl.style.left = myRight+"px";
});

document.getElementById("leftl").addEventListener("click", function(){
    myRight = myRight-5;
    mypicl.style.left = myRight+"px";
});

 document.getElementById("upl").addEventListener("click", function(){
    myTop = myTop-5;
    mypicl.style.top = myTop+"px";
});

document.getElementById("downl").addEventListener("click", function(){
    myTop = myTop+5;
    mypicl.style.top = myTop+"px";
});

document.getElementById("zoominl").addEventListener("click", function(){
    myHeight = myHeight+5;
    mypicl.style.height = myHeight+"px";
    myWidth = myWidth+5;
    mypicl.style.width = myWidth+"px";
});

document.getElementById("zoomoutl").addEventListener("click", function(){
    myHeight = myHeight-5;
    mypicl.style.height = myHeight+"px";
    myWidth = myWidth-5;
    mypicl.style.width = myWidth+"px";
});






var mypicr = document.getElementById("imageright");
var myTopr = 180;
var myRightr = 70;
var myHeightr = 150;
var myWidthr = 200;

document.getElementById("rightr").addEventListener("click", function(){
    myRightr = myRightr-5;
    mypicr.style.right = myRightr+"px";
});

document.getElementById("leftr").addEventListener("click", function(){
    myRightr = myRightr+5;
    mypicr.style.right = myRightr+"px";
});

 document.getElementById("upr").addEventListener("click", function(){
    myTopr = myTopr-5;
    mypicr.style.top = myTopr+"px";
});

document.getElementById("downr").addEventListener("click", function(){
    myTopr = myTopr+5;
    mypicr.style.top = myTopr+"px";
});

document.getElementById("zoominr").addEventListener("click", function(){
    myHeightr = myHeightr+5;
    mypicr.style.height = myHeightr+"px";
    myWidthr = myWidthr+5;
    mypicr.style.width = myWidthr+"px";
});

document.getElementById("zoomoutr").addEventListener("click", function(){
    myHeightr = myHeightr-5;
    mypicr.style.height = myHeightr+"px";
    myWidthr = myWidthr-5;
    mypicr.style.width = myWidthr+"px";
});







var mypict = document.getElementById("imagetop");
var myTopt = 70;
var myRightt = 450;
var myHeightt = 150;
var myWidtht = 200;

document.getElementById("rightt").addEventListener("click", function(){
    myRightt = myRightt-5;
    mypict.style.right = myRightt+"px";
});

document.getElementById("leftt").addEventListener("click", function(){
    myRightt = myRightt+5;
    mypict.style.right = myRightt+"px";
});

 document.getElementById("upt").addEventListener("click", function(){
    myTopt = myTopt-5;
    mypict.style.top = myTopt+"px";
});

document.getElementById("downt").addEventListener("click", function(){
    myTopt = myTopt+5;
    mypict.style.top = myTopt+"px";
});

document.getElementById("zoomint").addEventListener("click", function(){
    myHeightt = myHeightt+5;
    mypict.style.height = myHeightt+"px";
    myWidtht = myWidtht+5;
    mypict.style.width = myWidtht+"px";
});

document.getElementById("zoomoutt").addEventListener("click", function(){
    myHeightt = myHeightt-5;
    mypict.style.height = myHeightt+"px";
    myWidtht = myWidtht-5;
    mypict.style.width = myWidtht+"px";
});






var mypicb = document.getElementById("imagebottom");
var myTopb = 70;
var myRightb = 450;
var myHeightb = 150;
var myWidthb = 200;

document.getElementById("rightb").addEventListener("click", function(){
    myRightb = myRightb-5;
    mypicb.style.right = myRightb+"px";
});

document.getElementById("leftb").addEventListener("click", function(){
    myRightb = myRightb+5;
    mypicb.style.right = myRightb+"px";
});

 document.getElementById("upb").addEventListener("click", function(){
    myTopb = myTopb+5;
    mypicb.style.bottom = myTopb+"px";
});

document.getElementById("downb").addEventListener("click", function(){
    myTopb = myTopb-5;
    mypicb.style.bottom = myTopb+"px";
});

document.getElementById("zoominb").addEventListener("click", function(){
    myHeightb = myHeightb+5;
    mypicb.style.height = myHeightb+"px";
    myWidthb = myWidthb+5;
    mypicb.style.width = myWidthb+"px";
});

document.getElementById("zoomoutb").addEventListener("click", function(){
    myHeightb = myHeightb-5;
    mypicb.style.height = myHeightb+"px";
    myWidthb = myWidthb-5;
    mypicb.style.width = myWidthb+"px";
});







/************ I'm so sleepy ***********/


document.getElementById("openl").addEventListener("click",function(){
    document.getElementById("controlleft").style.left = "10px"
})

document.getElementById("closel").addEventListener("click",function(){
    document.getElementById("controlleft").style.left = "-40px"
});

document.getElementById("resetl").addEventListener("click",function(){
    myTop = 180;
    myRight = 70;
    myHeight = 150;
    myWidth = 200;
    
    mypicl.style.left = myRight+"px";
    mypicl.style.top = myTop+"px";
    mypicl.style.height = myHeight+"px";
    mypicl.style.width = myWidth+"px";
});






document.getElementById("openr").addEventListener("click",function(){
    document.getElementById("controlright").style.right = "10px"
})

document.getElementById("closer").addEventListener("click",function(){
    document.getElementById("controlright").style.right = "-40px"
});

document.getElementById("resetr").addEventListener("click",function(){
    myTopr = 180;
    myRightr = 70;
    myHeightr = 150;
    myWidthr = 200;
    
    mypicr.style.right = myRightr+"px"
    mypicr.style.top = myTopr+"px"
    mypicr.style.height = myHeightr+"px"
    mypicr.style.width = myWidthr+"px"
});






document.getElementById("opent").addEventListener("click",function(){
    document.getElementById("controltop").style.top = "-40px"
})

document.getElementById("closet").addEventListener("click",function(){
    document.getElementById("controltop").style.top = "10px"
});

document.getElementById("resett").addEventListener("click",function(){
    myTopt = 70;
    myRightt = 450;
    myHeightt = 150;
    myWidtht = 200;
    
    mypict.style.right = myRightt+"px"
    mypict.style.top = myTopt+"px"
    mypict.style.height = myHeightt+"px"
    mypict.style.width = myWidtht+"px"
});








document.getElementById("openb").addEventListener("click",function(){
    document.getElementById("controlbottom").style.bottom = "10px"
})

document.getElementById("closeb").addEventListener("click",function(){
    document.getElementById("controlbottom").style.bottom = "-40px"
});

document.getElementById("resetb").addEventListener("click",function(){
    myTopb = 70;
    myRightb = 450;
    myHeightb = 150;
    myWidthb = 200;
    
    mypicb.style.right = myRightb+"px"
    mypicb.style.bottom = myTopb+"px"
    mypicb.style.height = myHeightb+"px"
    mypicb.style.width = myWidthb+"px"
});
